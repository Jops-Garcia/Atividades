package chainofresponsability;


public class Main {    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {                                     
    
        
      TelaPagamentos tela = new TelaPagamentos();
      tela.setVisible(true);
       
    }    
    
}

   
