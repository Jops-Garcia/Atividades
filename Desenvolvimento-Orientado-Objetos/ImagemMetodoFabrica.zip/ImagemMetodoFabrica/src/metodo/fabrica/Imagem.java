
package metodo.fabrica;


class Imagem {
    
}
