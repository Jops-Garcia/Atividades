
package metodo.fabrica;


public class FormatoPng implements Formato{

    @Override
    public Imagem gera() {
        System.out.println("gera png");
        return null;
    }
    
    
    
}
