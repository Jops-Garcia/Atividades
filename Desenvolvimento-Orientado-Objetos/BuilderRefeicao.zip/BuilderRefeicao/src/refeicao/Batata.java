/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refeicao;

/**
 *
 * @author felip
 */
public class  Batata {
    
    private boolean comBatata;

    public boolean isComBatata() {
        return comBatata;
    }

    public void setComBatata(boolean comBatata) {
        this.comBatata = comBatata;
    }
    public Batata(){
        System.out.println("Cria Batata");
    }
}