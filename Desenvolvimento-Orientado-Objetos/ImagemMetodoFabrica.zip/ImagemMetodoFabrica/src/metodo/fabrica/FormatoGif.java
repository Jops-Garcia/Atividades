
package metodo.fabrica;


public class FormatoGif implements Formato{

    @Override
    public Imagem gera() {
        System.out.println("gera gif");
        return null;
    }
    
    
    
}
