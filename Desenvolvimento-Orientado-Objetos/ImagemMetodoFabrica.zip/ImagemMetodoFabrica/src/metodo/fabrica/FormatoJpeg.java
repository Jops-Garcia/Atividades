
package metodo.fabrica;


public class FormatoJpeg implements Formato{

    @Override
    public Imagem gera() {
        System.out.println("gera jpeg");
        return null;
    }
    
    
    
}
