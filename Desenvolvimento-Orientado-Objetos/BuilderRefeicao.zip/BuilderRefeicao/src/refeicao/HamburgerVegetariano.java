

package refeicao;

/**
 *
 * @author felipe
 */
public class HamburgerVegetariano implements Hamburger  {
    
}
