
package metodo.fabrica;


public interface Formato {
    
    public Imagem gera();
}
