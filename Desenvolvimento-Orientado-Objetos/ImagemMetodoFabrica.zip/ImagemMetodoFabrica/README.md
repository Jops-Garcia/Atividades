
Antes de fazer o exercício não esqueça de assistir a vídeo aula disponível em: 
https://youtu.be/S3Mamh_ugf8


Exercício -  Método Fábrica - Gerador de Imagens. 

Altere o código exemplo do gerador de imagems para que passe a gerar os formatos gif e bmp. 

Dica: Você precisa alterar a classe FabricaFormato.

