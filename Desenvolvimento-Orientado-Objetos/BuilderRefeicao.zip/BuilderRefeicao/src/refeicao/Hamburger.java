

package refeicao;

/**
 *
 * @author felipe
 */
public interface Hamburger {
    
}
